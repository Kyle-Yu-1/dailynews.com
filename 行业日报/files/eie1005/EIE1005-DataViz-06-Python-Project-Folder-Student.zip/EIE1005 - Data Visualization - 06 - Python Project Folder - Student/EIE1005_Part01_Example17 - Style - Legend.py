import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

fig = plt.figure(figsize=(15, 9))
plt.subplots_adjust(top=0.9, bottom=0.1, left=0.1, right=0.95)
fig.suptitle('Example 17 - Style - Legend', fontsize=24)

gs = gridspec.GridSpec(1, 1)
ax1 = fig.add_subplot(gs[0, 0])

df_price = pd.read_excel('EIE1005_Part01_Data.xlsx', sheet_name='Price')
df_price.plot(ax=ax1, kind='bar', x='Year', y='Apple Price')
ax1.legend(loc='best')
# ax1.legend().set_visible(False)

plt.show()
