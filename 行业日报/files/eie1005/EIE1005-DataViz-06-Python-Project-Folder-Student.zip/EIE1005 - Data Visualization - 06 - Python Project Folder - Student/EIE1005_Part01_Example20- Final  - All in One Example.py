import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

fig = plt.figure(figsize=(15, 9))
plt.subplots_adjust(top=0.9, bottom=0.1, left=0.1, right=0.95)
fig.suptitle('Example 20 - All in One', fontsize=24)

gs = gridspec.GridSpec(2, 2)
ax1 = fig.add_subplot(gs[:, 0])
ax2 = fig.add_subplot(gs[0, 1])
ax3 = fig.add_subplot(gs[1, 1])

df_price_01 = pd.read_excel('EIE1005_Part01_Data.xlsx', sheet_name='Price')
df_price_01.plot(ax=ax1, kind='bar', x='Year', color=['y','b'])
ax1.set_title('Apple and Orange - Price Over Years')
ax1.set_xlabel('Year')
ax1.set_ylabel('Price in USD $')

df_price_02 = pd.read_excel('EIE1005_Part01_Data.xlsx', sheet_name='Price')
df_price_02.plot(ax=ax2, kind='line', marker='o', x='Year', y='Apple Price', color='y')
ax2.set_title('Apple Price Over Years')
ax2.grid(visible=True)

df_price_03 = pd.read_excel('EIE1005_Part01_Data.xlsx', sheet_name='Price')
df_price_03.plot(ax=ax3, kind='line', marker='o', x='Year', y='Orange Price', color='b')
ax3.set_title('Orange Price Over Years')
ax3.legend(loc='best')

plt.show()