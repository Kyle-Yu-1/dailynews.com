import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

fig = plt.figure(figsize=(15, 9))
plt.subplots_adjust(top=0.9, bottom=0.1, left=0.1, right=0.95)
fig.suptitle('Example 12 - Chart Layout - 2 Chart', fontsize=24)

gs = gridspec.GridSpec(1, 2)
ax1 = fig.add_subplot(gs[0, 0])
ax2 = fig.add_subplot(gs[0, 1])

df_price_01 = pd.read_excel('EIE1005_Part01_Data.xlsx', sheet_name='Price')
df_price_01.plot(ax=ax1, kind='bar', x='Year', y='Apple Price')

df_price_02 = pd.read_excel('EIE1005_Part01_Data.xlsx', sheet_name='Price')
df_price_02.plot(ax=ax2, kind='bar', x='Year', y='Orange Price')

plt.show()
