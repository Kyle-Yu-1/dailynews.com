import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

fig = plt.figure(figsize=(15, 9))
plt.subplots_adjust(top=0.9, bottom=0.1, left=0.1, right=0.95)
fig.suptitle('Example 01 - Simple Chart - Pandas DataFrame', fontsize=24)

gs = gridspec.GridSpec(1, 1)
ax1 = fig.add_subplot(gs[0, 0])

data = {'Year' : [2022, 2023, 2024, 2025],
        'Apple Price' : [20, 25, 18, 28],
        'Orange Price' : [16, 18, 20, 26]}
df_price = pd.DataFrame(data)
df_price.plot(ax=ax1, kind='line', x='Year', y='Apple Price')

plt.show()
